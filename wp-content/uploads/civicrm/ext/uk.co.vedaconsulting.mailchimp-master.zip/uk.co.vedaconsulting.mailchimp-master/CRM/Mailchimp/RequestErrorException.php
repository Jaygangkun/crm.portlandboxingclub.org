<?php
/**
 * @file
 * Exception for all Mailchimp API operations that result in a 4xx error.
 */

class CRM_Mailchimp_RequestErrorException extends CRM_Mailchimp_Exception {}
