# Mailchimp Sync

A new for 2020 extension for a more robust and flexible mailchimp sync. If
you *have to* use Mailchimp, this might be useful to you.

Please see
[Full Documentation](https://docs.civicrm.org/mailchimpsync/en/latest)

Please also browse the [Issue
queue](https://lab.civicrm.org/extensions/mailchimpsync/issues). We'd
welcome your input, especially on ones labelled **discussion**.

- Author: Rich Lott / [Artful Robot](https://artfulrobot.uk)
- Copyright: Copyright (C) 2019, Rich Lott / Artful Robot
- License: [AGPL-3](./LICENSE.txt)
