# Installation

You can install this extension in any of the normal ways.

It's not yet listed for installation from within CiviCRM.

## Method 1

Download the [latest release](https://lab.civicrm.org/extensions/mailchimpsync/-/releases) and unzip it into your extensions directory.

Then navigate to **CiviCRM » Administer » System Settings » Extensions** and click **Install**.

## Method 2

Developers can clone the Git repo into your extensions directory, grab the links from <https://lab.civicrm.org/extensions/mailchimpsync>

## Uninstall/remove

In the normal way.

