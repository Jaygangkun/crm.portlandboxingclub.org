(function(angular, $, _) {
  // Declare a list of dependencies.
  angular.module('mailchimpsync', CRM.angRequires('mailchimpsync'));
})(angular, CRM.$, CRM._);
