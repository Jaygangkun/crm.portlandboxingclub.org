<?php
class CRM_Mailchimpsync_BatchWebhookNotRelevantException extends \Exception {}
