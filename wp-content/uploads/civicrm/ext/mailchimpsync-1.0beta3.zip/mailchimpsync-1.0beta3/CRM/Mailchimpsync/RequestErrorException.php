<?php
class CRM_Mailchimpsync_RequestErrorException extends Exception
{
}
