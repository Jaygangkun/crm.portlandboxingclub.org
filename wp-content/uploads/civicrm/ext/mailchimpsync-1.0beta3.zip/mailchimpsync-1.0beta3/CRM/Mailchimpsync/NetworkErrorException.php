<?php
class CRM_Mailchimpsync_NetworkErrorException extends Exception
{
}

