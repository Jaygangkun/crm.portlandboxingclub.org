DROP TABLE IF EXISTS civicrm_mailchimpsync_status;
