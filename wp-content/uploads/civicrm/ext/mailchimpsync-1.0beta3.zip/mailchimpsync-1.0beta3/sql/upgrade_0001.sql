ALTER TABLE `civicrm_mailchimpsync_update` ADD `created_date` timestamp   DEFAULT CURRENT_TIMESTAMP COMMENT 'When was the update created';
