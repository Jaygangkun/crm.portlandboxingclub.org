(function(angular, $, _) {
  "use strict";

  // Declare module
  angular.module('crmSearchDisplayList', CRM.angRequires('crmSearchDisplayList'));

})(angular, CRM.$, CRM._);
